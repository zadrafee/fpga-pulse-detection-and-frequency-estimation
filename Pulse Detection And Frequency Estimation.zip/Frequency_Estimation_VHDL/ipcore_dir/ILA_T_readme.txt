The following files were generated for 'ILA_T' in directory
D:\Projects\37\Digital IFM\IF_FFT\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * ILA_T.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * ILA_T.cdc
   * ILA_T.constraints/ILA_T.ucf
   * ILA_T.constraints/ILA_T.xdc
   * ILA_T.ncf
   * ILA_T.ngc
   * ILA_T.ucf
   * ILA_T.vhd
   * ILA_T.vho
   * ILA_T.xdc
   * ILA_T_xmdf.tcl

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * ILA_T.vho

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * ILA_T.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * ILA_T.sym

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * ILA_T.gise
   * ILA_T.xise
   * _xmsgs/pn_parser.xmsgs

Deliver Readme:
   Readme file for the IP.

   * ILA_T_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * ILA_T_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

