The following files were generated for 'ICON_T' in directory
D:\Projects\37\Digital IFM\IF_FFT\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * ICON_T.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * ICON_T.constraints/ICON_T.ucf
   * ICON_T.constraints/ICON_T.xdc
   * ICON_T.ngc
   * ICON_T.ucf
   * ICON_T.vhd
   * ICON_T.vho
   * ICON_T.xdc
   * ICON_T_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * ICON_T.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * ICON_T.sym

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * ICON_T.gise
   * ICON_T.xise
   * _xmsgs/pn_parser.xmsgs

Deliver Readme:
   Readme file for the IP.

   * ICON_T_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * ICON_T_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

